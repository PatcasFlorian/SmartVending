﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SmartVending.Models;

namespace SmartVending.Data
{
    public class SmartVendingContext : DbContext
    {
        public SmartVendingContext (DbContextOptions<SmartVendingContext> options)
            : base(options)
        {
        }

        public DbSet<SmartVending.Models.Locatii> Locatii { get; set; }
    }
}
