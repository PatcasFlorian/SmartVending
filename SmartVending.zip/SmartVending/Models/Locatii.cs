﻿using System;

namespace SmartVending.Models
{
    public class Locatii
    {
        public int Id { get; set; }
        public string NumeLocatie { get; set; }
        public string AdresaLocati { get; set; }
        public double TotalIncasare { get; set; }
        public double IncasareAnterioara { get; set; }
        public double IncasareActuala { get; set; }
    }
}
