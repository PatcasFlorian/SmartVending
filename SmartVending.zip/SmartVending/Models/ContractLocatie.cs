﻿using System;

namespace SmartVending.Models
{
    public class ContractLocatie
    {
        public int Id { get; set; }
        public string NumeLocatie { get; set; }
        public string NumarContract { get; set; }
        public DateTime? DataContractului { get; set; }
        public DateTime? ValabilitateContract { get; set; }
    }
}
