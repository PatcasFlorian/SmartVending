﻿using System;

namespace SmartVending.Models
{
    public class TipAparat
    {
        public string SerieAparat { get; set; }
        public DateTime? DataCitireAparat { get; set; }
        public int ContorPortii { get; set; }
        public int DiferentaContorPortii { get; set; }
        public double PretProduse { get; set; }
        public double BaniInCutie { get; set; }
        public double DiferentaIncasare { get; set; }
        public string TipApara { get; set; }
        public DateTime? DataRevizie { get; set; }


    }
}
